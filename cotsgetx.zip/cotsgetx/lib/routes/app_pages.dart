import 'package:get/get.dart';
import 'package:cotsgetx/modules/onboarding/view/onboarding_page.dart'; // OnboardingPage
import 'package:cotsgetx/modules/onboarding/bindings/onboarding_binding.dart'; // OnboardingBinding
import 'package:cotsgetx/modules/login/view/login_page.dart'; // LoginPage
import 'package:cotsgetx/modules/main/view/home_page.dart'; // HomePage
import 'package:cotsgetx/modules/main/view/pesanan_page.dart'; // PesananPage
import 'package:cotsgetx/modules/main/view/promo_page.dart'; // PromoPage

class AppPages {
  static const String onboarding = '/onboarding';
  static const String login = '/login';
  static const String home = '/home';
  static const String pesanan = '/pesanan';
  static const String promo = '/promo';

  static final routes = [
    // Rute untuk halaman onboarding
    GetPage(
      name: onboarding,
      page: () => OnboardingPage(),
      binding: OnboardingBinding(), // Pastikan binding digunakan
    ),

    // Rute untuk halaman login
    GetPage(
      name: login,
      page: () => LoginPage(),
    ),

    // Rute untuk halaman home
    GetPage(
      name: home,
      page: () => HomePage(),
    ),

    // Rute untuk halaman pesanan
    GetPage(
      name: pesanan,
      page: () => PesananPage(),
    ),

    // Rute untuk halaman promo
    GetPage(
      name: promo,
      page: () => PromoPage(),
    ),
  ];
}
