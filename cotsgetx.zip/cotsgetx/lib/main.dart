import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'routes/app_pages.dart'; // Pastikan file ini ada dan terhubung

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'CotsGetX',
      initialRoute: AppPages.onboarding, // Halaman pertama yang muncul
      getPages: AppPages.routes, // Menyertakan rute yang ada di AppPages
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
    );
  }
}
