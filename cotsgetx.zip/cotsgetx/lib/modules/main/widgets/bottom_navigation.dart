import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controller/main_controller.dart';

class BottomNavigation extends StatelessWidget {
  final MainController controller;

  BottomNavigation({required this.controller});

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: controller.selectedIndex.value,
      onTap: (index) {
        controller.updateSelectedIndex(index); // Mengubah tab yang aktif
      },
      items: [
        BottomNavigationBarItem(
          icon: Icon(Icons.home),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.local_offer),
          label: 'Promo',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.shopping_cart),
          label: 'Order',
        ),
      ],
    );
  }
}
