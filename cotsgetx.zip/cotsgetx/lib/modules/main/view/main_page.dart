import 'package:cotsgetx/modules/main/view/home_page.dart';
import 'package:cotsgetx/modules/main/view/pesanan_page.dart';
import 'package:cotsgetx/modules/main/view/promo_page.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controller/main_controller.dart';
import '../widgets/bottom_navigation.dart';

class MainPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final MainController controller = Get.find();

    return Scaffold(
      appBar: AppBar(
        title: Text('Main Page'),
      ),
      body: Obx(() {
        // Menggunakan Obx untuk mendengarkan perubahan selectedIndex
        switch (controller.selectedIndex.value) {
          case 0:
            return HomePage();
          case 1:
            return PromoPage();
          case 2:
            return PesananPage();
          default:
            return HomePage();
        }
      }),
      bottomNavigationBar: BottomNavigation(controller: controller),
    );
  }
}
