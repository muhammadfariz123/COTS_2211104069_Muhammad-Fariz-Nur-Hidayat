import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../routes/app_pages.dart'; // Rute untuk navigasi

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Home Page")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                // Navigasi ke halaman promo
                Get.toNamed(
                    AppPages.promo); // Gunakan konstanta dari app_pages.dart
              },
              child: Text("Go to Promo Page"),
            ),
            ElevatedButton(
              onPressed: () {
                // Navigasi ke halaman pesanan
                Get.toNamed(
                    AppPages.pesanan); // Gunakan konstanta dari app_pages.dart
              },
              child: Text("Go to Pesanan Page"),
            ),
          ],
        ),
      ),
    );
  }
}
