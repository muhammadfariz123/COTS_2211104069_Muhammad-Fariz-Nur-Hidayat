import 'package:get/get.dart';

class MainController extends GetxController {
  var selectedIndex = 0.obs; // Menyimpan index tab yang aktif

  void updateSelectedIndex(int index) {
    selectedIndex.value = index;
  }
}
