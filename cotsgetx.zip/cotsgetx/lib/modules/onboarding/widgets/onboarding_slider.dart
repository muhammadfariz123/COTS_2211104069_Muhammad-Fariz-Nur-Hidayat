import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controller/onboarding_controller.dart'; // Import controller

class OnboardingSlider extends StatelessWidget {
  final OnboardingController controller;

  OnboardingSlider({required this.controller});

  final List<String> images = [
    'lib/assets/images/jam.jpg',
    'lib/assets/images/sepatu.jpg',
    'lib/assets/images/shop.jpg',
    'lib/assets/images/tas.jpg'
  ];

  @override
  Widget build(BuildContext context) {
    return PageView.builder(
      onPageChanged: (index) {
        controller.changeIndex(index); // Mengubah index ketika gambar berganti
      },
      itemCount: images.length,
      itemBuilder: (context, index) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Image.asset(
            images[index],
            fit: BoxFit.cover, // Agar gambar memenuhi kontainer
          ),
        );
      },
    );
  }
}
