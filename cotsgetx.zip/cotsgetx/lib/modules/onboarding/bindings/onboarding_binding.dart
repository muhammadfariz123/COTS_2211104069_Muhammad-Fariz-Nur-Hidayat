import 'package:get/get.dart';
import '../controller/onboarding_controller.dart'; // Import OnboardingController

class OnboardingBinding extends Bindings {
  @override
  void dependencies() {
    // Daftarkan controller menggunakan Get.lazyPut()
    Get.lazyPut<OnboardingController>(() => OnboardingController());
  }
}
