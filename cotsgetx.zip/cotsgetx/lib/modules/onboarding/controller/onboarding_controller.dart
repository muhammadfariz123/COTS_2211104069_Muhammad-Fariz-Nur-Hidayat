import 'package:get/get.dart';

class OnboardingController extends GetxController {
  var currentIndex = 0.obs;

  get skipOnboarding => null;

  get currentPage => null;

  get finishOnboarding => null; // Menyimpan index slider yang sedang aktif

  // Method untuk mengubah slide
  void changeIndex(int index) {
    currentIndex.value = index;
  }
}
