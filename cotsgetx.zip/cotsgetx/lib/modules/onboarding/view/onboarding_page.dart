import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../widgets/onboarding_slider.dart'; // Untuk slider onboarding
import '../../../routes/app_pages.dart'; // Rute untuk navigasi
import '../controller/onboarding_controller.dart'; // Import controller

class OnboardingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Mendapatkan instance OnboardingController yang sudah didaftarkan
    final OnboardingController controller = Get.find<OnboardingController>();

    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Menampilkan slider onboarding
            Expanded(
              child: OnboardingSlider(controller: controller),
            ),

            // Tombol navigasi ke halaman login
            Padding(
              padding: const EdgeInsets.only(top: 20.0),
              child: ElevatedButton(
                onPressed: () {
                  // Navigasi ke halaman login setelah menekan tombol
                  Get.toNamed(
                      AppPages.login); // Gunakan konstanta dari app_pages.dart
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue, // Warna tombol
                  padding: EdgeInsets.symmetric(horizontal: 100, vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: Text(
                  'Get Started',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
