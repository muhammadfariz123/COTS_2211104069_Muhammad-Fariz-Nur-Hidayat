import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controller/login_controller.dart'; // Pastikan sudah di-import

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Pastikan controller sudah didaftarkan
    final LoginController controller =
        Get.put(LoginController()); // Dafftarkan controller

    return Scaffold(
      resizeToAvoidBottomInset:
          false, // Agar tidak tumpang tindih dengan keyboard
      body: Stack(
        children: [
          // Background Image
          Positioned.fill(
            child: Image.asset(
              'lib/assets/images/jam.jpg', // Ganti dengan gambar yang diinginkan
              fit: BoxFit.cover,
            ),
          ),

          // Konten Halaman Login
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Logo atau header
                Center(
                  child: Image.asset(
                    'lib/assets/images/shop.jpg', // Ganti dengan logo
                    width: 120,
                    height: 120,
                  ),
                ),
                SizedBox(height: 30),

                // Judul Halaman Login
                Text(
                  'Welcome Back!',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 5),
                Text(
                  'Please login to continue.',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white70,
                  ),
                ),
                SizedBox(height: 30),

                // Form Input untuk Nomor Telepon
                TextField(
                  controller: controller.phoneController,
                  keyboardType: TextInputType.phone,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.white.withOpacity(0.8),
                    hintText: 'Phone Number',
                    prefixIcon: Icon(Icons.phone, color: Colors.blue),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding:
                        EdgeInsets.symmetric(vertical: 18, horizontal: 20),
                  ),
                ),
                SizedBox(height: 20),

                // Form Input untuk Password
                TextField(
                  controller: controller.passwordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.white.withOpacity(0.8),
                    hintText: 'Password',
                    prefixIcon: Icon(Icons.lock, color: Colors.blue),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding:
                        EdgeInsets.symmetric(vertical: 18, horizontal: 20),
                  ),
                ),
                SizedBox(height: 20),

                // Tombol Login
                ElevatedButton(
                  onPressed: () {
                    controller.login(); // Panggil fungsi login di controller
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue, // Warna tombol
                    padding:
                        EdgeInsets.symmetric(horizontal: 100, vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  child: Text(
                    'Login',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),

                // Teks di bawah tombol login
                SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Don\'t have an account? ',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.white,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        // Navigasi ke halaman registrasi
                        Get.toNamed('/signup');
                      },
                      child: Text(
                        'Sign Up',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.blueAccent,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10),

                // Tautan lupa password
                Center(
                  child: GestureDetector(
                    onTap: () {
                      // Navigasi ke halaman lupa password
                      Get.toNamed('/forgot-password');
                    },
                    child: Text(
                      'Forgot your password?',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.blueAccent,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
