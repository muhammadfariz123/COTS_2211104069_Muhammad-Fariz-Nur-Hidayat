import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LoginController extends GetxController {
  // TextEditingController untuk nomor telepon dan password
  TextEditingController phoneController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  get isPhoneValid => null;

  // Fungsi untuk melakukan login
  void login() {
    String phone = phoneController.text;
    String password = passwordController.text;

    // Validasi sederhana
    if (phone.isEmpty || password.isEmpty) {
      Get.snackbar(
        'Error',
        'Phone number and password cannot be empty.',
        snackPosition: SnackPosition.BOTTOM,
      );
    } else {
      // Navigasi ke halaman home setelah login sukses
      Get.toNamed('/home');
    }
  }

  void validatePhone(String value) {}
}
