import 'package:cotsgetx/modules/login/controller/login_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LoginForm extends StatelessWidget {
  final LoginController controller;

  LoginForm({required this.controller});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Nomor Telepon', style: TextStyle(fontSize: 16)),
        TextFormField(
          keyboardType: TextInputType.phone,
          onChanged: (value) {
            controller.validatePhone(value); // Validasi setiap input
          },
          decoration: InputDecoration(
            hintText: 'Masukkan nomor telepon',
            border: OutlineInputBorder(),
          ),
        ),
        Obx(() {
          return Text(
            controller.isPhoneValid.value
                ? 'Nomor Telepon Valid'
                : 'Nomor Telepon Tidak Valid',
            style: TextStyle(
                color:
                    controller.isPhoneValid.value ? Colors.green : Colors.red),
          );
        }),
      ],
    );
  }
}
