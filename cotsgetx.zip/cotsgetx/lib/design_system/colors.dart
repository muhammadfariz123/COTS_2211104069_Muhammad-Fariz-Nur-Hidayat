import 'package:flutter/material.dart';

class PrimaryColors {
  static const Color primaryRed = Color(0xFFEE2737); // Warna utama merah
  static const Color primaryBlue = Color(0xFF0071CE); // Warna utama biru
  static const Color primaryGreen = Color(0xFF39B54A); // Warna utama hijau
  static const Color primaryYellow = Color(0xFFFFC20E); // Warna utama kuning

  static const Color background = Color(0xFFF5F5F5); // Warna background
  static const Color text = Color(0xFF333333); // Warna teks utama
}
