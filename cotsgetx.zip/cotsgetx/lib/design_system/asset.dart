class AppAssets {
  // Gambar
  static const String logo = 'assets/images/logo.png';
  static const String banner = 'assets/images/banner.jpg';

  // Ikon
  static const String homeIcon = 'assets/icons/home_icon.svg';
  static const String profileIcon = 'assets/icons/profile_icon.svg';
  static const String settingsIcon = 'assets/icons/settings_icon.svg';

  // Audio (Jika ada)
  static const String notificationSound = 'assets/audio/notification_sound.mp3';

  // Lainnya (jika ada jenis aset lain)
  static const String splashBackground = 'assets/images/splash_background.png';
}
