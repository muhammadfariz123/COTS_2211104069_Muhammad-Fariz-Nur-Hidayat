import 'package:flutter/material.dart';

// Fungsi untuk memvalidasi email
bool isValidEmail(String email) {
  String pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
  RegExp regex = RegExp(pattern);
  return regex.hasMatch(email);
}

// Fungsi untuk memvalidasi nomor telepon
bool isValidPhoneNumber(String phoneNumber) {
  String pattern =
      r'^[0-9]{10,15}$'; // Nomor telepon dengan panjang 10-15 digit
  RegExp regex = RegExp(pattern);
  return regex.hasMatch(phoneNumber);
}

// Fungsi untuk mengubah format tanggal
String formatDate(DateTime date) {
  return "${date.day.toString().padLeft(2, '0')}-${date.month.toString().padLeft(2, '0')}-${date.year}";
}

// Fungsi untuk menampilkan SnackBar dengan pesan
void showSnackBar(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(message),
      duration: Duration(seconds: 2),
    ),
  );
}

// Fungsi untuk menampilkan loading indicator
void showLoadingIndicator(BuildContext context) {
  showDialog(
    context: context,
    barrierDismissible:
        false, // Tidak dapat menutup dialog dengan mengetuk di luar
    builder: (BuildContext context) {
      return Center(
        child: CircularProgressIndicator(),
      );
    },
  );
}

// Fungsi untuk menutup loading indicator
void hideLoadingIndicator(BuildContext context) {
  Navigator.of(context).pop(); // Menutup dialog jika sudah ada
}

// Fungsi untuk memformat harga dengan pemisah ribuan
String formatCurrency(double amount) {
  return "Rp ${amount.toStringAsFixed(0).replaceAll(RegExp(r'\B(?=(\d{3})+(?!\d))'), '.')}";
}

// Fungsi untuk memvalidasi password (minimal 6 karakter)
bool isValidPassword(String password) {
  return password.length >= 6;
}

// Fungsi untuk konversi angka ke format persen
String formatPercentage(double value) {
  return "${(value * 100).toStringAsFixed(1)}%";
}
