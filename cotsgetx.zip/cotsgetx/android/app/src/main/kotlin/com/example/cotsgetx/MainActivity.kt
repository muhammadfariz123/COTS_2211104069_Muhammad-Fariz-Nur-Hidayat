package com.example.cotsgetx

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
